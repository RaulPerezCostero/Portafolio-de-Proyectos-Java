package model;

import java.io.File;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.coti.tools.Rutas;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class JSONExporter implements IExporter{

    //Atributos
    Path rutaJSON = Rutas.pathToFileOnDesktop("tareas.JSON");
    ArrayList<Task> tar = new ArrayList<>();
    private Set<String> idsDesdeBinario = new HashSet<>();
    private static HashSet<String> idsImportados = new HashSet<>();

    //Metodo para cargar los ids y evitar que se dupliquen
    private void cargarIdsImportados() {
        Path rutaIds = Rutas.pathToFileOnDesktop("ids_importados.json");
        if (Files.exists(rutaIds)) {
            try {
                List<String> idsGuardados = Files.readAllLines(rutaIds, StandardCharsets.UTF_8);
                idsImportados.addAll(idsGuardados);
            } catch (Exception e) {
                System.err.println("\u001b[31mError al cargar los IDs importados.\u001b[0m");
            }
        }
    }


    //Metodo para exportar en JSON
    @Override
    public void exportarTareas(ArrayList<Task> tareas) {
        try {
            if (tareas == null || tareas.isEmpty()) {
                System.err.println("\u001b[31mLa lista de tareas está vacía. No se exportará nada.\u001b[0m");
                return;
            }
            Gson gson = new Gson();
            String json = gson.toJson(tareas);
            Files.write(rutaJSON, json.getBytes(StandardCharsets.UTF_8));
            System.out.println("\u001b[32mExportado correctamente a: \u001b[35m" + rutaJSON + "\u001b[0m");
        } catch (Exception e) {
            System.err.println("\u001b[31mOcurrió un error al exportar.\u001b[0m");
            e.printStackTrace();
        }
    }

    //Metodo para importar en JSON
    @Override
    public ArrayList<Task> importarTareas() {
        File f = rutaJSON.toFile();
        if (!f.exists() || !f.isFile()) {
            System.err.println("\u001b[31mEl archivo JSON no existe o no es válido.\u001b[0m");
            return tar;
        }

        try {
            Gson gson = new Gson();
            String json = new String(Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
            Type tipo = new TypeToken<ArrayList<Task>>() {}.getType();
            ArrayList<Task> tareasImportadas = gson.fromJson(json, tipo);

            //Cargamos los IDs previamente importados antes de procesar las tareas
            cargarIdsImportados();

            for (Task task : tareasImportadas) {
                if (task == null || task.getId() == null) {
                    System.out.println("\u001b[31mTarea con ID inválido o nulo: " + task + "\u001b[0m");
                    continue;
                }

                //Verificamos si el ID ya está cargado desde el binario
                if (idsDesdeBinario.contains(task.getId())) {
                    System.out.println("\u001b[31mLa tarea con ID " + task.getId() + " ya fue cargada desde el binario. No se puede importar del JSON.\u001b[0m");
                    continue;
                }

                //Verificamos si el ID ya fue importado previamente
                if (idsImportados.contains(task.getId())) {
                    System.out.println("\u001b[31mLa tarea con ID " + task.getId() + " ya ha sido importada previamente. No se importará.\u001b[0m");
                    continue;
                }

                tar.add(task);
                idsImportados.add(task.getId());
                System.out.println("\u001b[32mTarea importada con éxito: " + task.getId() + "\u001b[0m");
            }

            //Ordenamos los IDs por Decha de menor a mayor
            Collections.sort(tar, new Comparator<Task>() {
                @Override
                public int compare(Task t1, Task t2) {
                    return t1.getFecha().compareTo(t2.getFecha());
                }
            });

        } catch (Exception e) {
            System.err.println("\u001b[31mError al intentar importar las tareas desde JSON.\u001b[0m");
            e.printStackTrace();
        }

        return tar;
    }

    //Metodo setter para establecer el valor del atributo
    public void setIdsDesdeBinario(Set<String> idsDesdeBinario) {
        this.idsDesdeBinario = idsDesdeBinario;
    }
}
