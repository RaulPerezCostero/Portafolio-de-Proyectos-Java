package model;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.coti.tools.Rutas;

public class CSVExporter implements IExporter {

    //Atributos
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
    Path ruta = Rutas.pathToFileOnDesktop("tareas.csv");
    ArrayList<Task> tar = new ArrayList<>();
    private Set<String> idsDesdeBinario = new HashSet<>();
    private static HashSet<String> idsImportados = new HashSet<>();

    //Guarda los IDs importados para que no se dupliquen
    private void cargarIdsImportados() {
        Path rutaIds = Rutas.pathToFileOnDesktop("ids_importados.txt");
        if (Files.exists(rutaIds)) {
            try {
                List<String> idsGuardados = Files.readAllLines(rutaIds, StandardCharsets.UTF_8);
                idsImportados.addAll(idsGuardados);
            } catch (IOException e) {
                System.err.println("\u001b[31mError al cargar los IDs importados.\u001b[0m");
            }
        }
    }

    //Metodo para exportar a CSV
    @Override
    public void exportarTareas(ArrayList<Task> tareas) {
        ArrayList<String> lineas = new ArrayList<>();
        String delimitador = ",";
        for (Task linea : tareas) {
            lineas.add(linea.toStringCSV(delimitador));
        }
        try {
            Files.write(ruta, lineas, StandardCharsets.UTF_8);
            System.out.println("\u001b[32mExportado correctamente a: \u001b[35m" + ruta + "\u001b[0m");
        } catch (Exception e) {
            System.err.println("\u001b[31mError al exportar.\u001b[0m");
            e.printStackTrace();
        }
    }

    //Metodo para importar a CSV
    @Override
    public ArrayList<Task> importarTareas() {
        File f = ruta.toFile();
        if (f.exists() && f.isFile()) {
            try {

                String delimitador = ",";
                List<String> lineas = Files.readAllLines(ruta);

                for (String linea : lineas) {
                    Task task = Task.getTareasFromDelimitedString(linea, delimitador);

                    if (task == null || task.getId() == null) {
                        System.out.println("\u001b[31mLa tarea tiene un ID inválido o nulo: " + linea + "\u001b[0m");
                        continue;
                    }

                    System.out.println("id: " + task.getId());
                    for (String string : idsImportados) {
                        System.out.println(string);
                    }

                    //Verificar si el ID ya está cargado desde el binario.
                    if (idsDesdeBinario.contains(task.getId())) {
                        System.out.println("\u001b[31mLa tarea con ID " + task.getId() + " ya fue cargada desde el binario. No se puede importar del CSV.\u001b[0m");
                        continue;
                    }


                    if (idsImportados.contains(task.getId())) {
                        System.out.println("\u001b[31mLa tarea con ID " + task.getId() + " ya ha sido importada previamente. No se importará.\u001b[0m");
                        continue;
                    }
                    tar.add(task);
                    System.out.println("Tarea importada con éxito: " + task.getId());
                    
                }

                cargarIdsImportados();

                Collections.sort(tar, new Comparator<Task>() {
                    @Override
                    public int compare(Task t1, Task t2) {
                        return t1.getFecha().compareTo(t2.getFecha());
                    }
                });

            } catch (Exception e) {
                System.err.println("\u001b[31mOcurrió un error al intentar importar los datos.\u001b[0m");
                e.printStackTrace();
            }
        } else {
            System.err.println("\u001b[31mEl archivo no existe o no es un archivo válido.\u001b[0m");
        }

        return tar;
    }

    //Metodo setter para establecer el valor del atributo
    public void setIdsDesdeBinario(Set<String> idsDesdeBinario) {
        this.idsDesdeBinario = idsDesdeBinario;
    }
}
