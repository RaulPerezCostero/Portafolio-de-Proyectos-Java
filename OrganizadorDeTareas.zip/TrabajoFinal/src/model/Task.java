package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class Task implements Serializable{

    //Atributos
    private String id;
    private String titulo;
    private Date fecha;
    private String contenido;
    private int prioridad;
    private int duracionEstimada;
    private boolean completada;
    private static final SimpleDateFormat DATEFORMAT = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
    
    //Constructores con argumentos
    public Task(String titulo, Date fecha, String contenido, int prioridad, int duracionEstimada,
            boolean completada) {
        this.id = UUID.randomUUID().toString();
        this.titulo = titulo;
        this.fecha = fecha;
        this.contenido = contenido;
        this.prioridad = prioridad;
        this.duracionEstimada = duracionEstimada;
        this.completada = completada;
    }
    
    public Task(String id, String titulo, Date fecha, String contenido, int prioridad, int duracionEstimada,
            boolean completada) {
        this.id = id;
        this.titulo = titulo;
        this.fecha = fecha;
        this.contenido = contenido;
        this.prioridad = prioridad;
        this.duracionEstimada = duracionEstimada;
        this.completada = completada;
    }
    //Constructor vacio
    public Task() {

    }

    //Metodos ncesarios para importar
    public static Task getTareasFromDelimitedString(String delimitedString, String delimiter){
    
        String[] chunks = delimitedString.split(delimiter); //Separamos por el delimitador

        if(chunks.length != 7){
            System.err.println("\u001b[31mLínea no válida: longitud incorrecta. \u001b[0m" + delimitedString);
            return null;
        }
        try{
            String id = chunks[0];
            String titulo = chunks[1];
            Date fecha = DATEFORMAT.parse(chunks[2]);
            String contenido = chunks[3];
            int prioridad = Integer.parseInt(chunks[4]);
            int duracion = Integer.parseInt(chunks[5]);
            boolean compleada = Boolean.parseBoolean(chunks[6]);
            return new Task(id, titulo, fecha, contenido, prioridad, duracion, compleada);
            
        }
        catch(Exception e){
            System.err.println("\u001b[31mError al procesar la línea: \u001b[0m" + delimitedString);
            return null;
        }
    }

    //Metodos toString()
    @Override
    public String toString(){
        return String.format("\u001b[32m                 | %-2s | %-25s | %-20s | %-11d | %-7s | \u001b[35m%-11s\u001b[32m |\u001b[0m",
                             id, titulo, DATEFORMAT.format(fecha), prioridad, String.format("%-11s", duracionEstimada + " min"), completada ? "Sí" : "No"); //Omitimos el contenido para asi tener una vista clara y rapida de las tareas que hay.
    }


    public String toStringCSV(String delimitador){
        return String.format(Locale.ENGLISH, "%s" + delimitador + "%s" + delimitador + "%s" + delimitador + "%s"+ delimitador +"%d"+ delimitador +"%d"+ delimitador + "%s",
                                    id, titulo, DATEFORMAT.format(fecha), contenido, prioridad, duracionEstimada, completada);
    }

    //Setters y getters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getDuracionEstimada() {
        return duracionEstimada;
    }

    public void setDuracionEstimada(int duracionEstimada) {
        this.duracionEstimada = duracionEstimada;
    }

    public boolean isCompletada() {
        return completada;
    }

    public void setCompletada(boolean completada) {
        this.completada = completada;
    }


}
