package model;

import java.util.ArrayList;

public interface IRepository {

    public void agregarTarea(Task t);

    public void modificarTarea(Task t);

    public void eliminarTarea();

    public ArrayList<Task> getTodasTareas();

    public void marcarTarea();


}
