package model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;

import com.coti.tools.Esdia;

import notion.api.v1.NotionClient;
import notion.api.v1.http.OkHttp5Client;
import notion.api.v1.logging.Slf4jLogger;
import notion.api.v1.model.databases.QueryResults;
import notion.api.v1.model.pages.Page;
import notion.api.v1.model.pages.PageParent;
import notion.api.v1.model.pages.PageProperty;
import notion.api.v1.model.pages.PageProperty.RichText;
import notion.api.v1.model.pages.PageProperty.RichText.Text;
import notion.api.v1.request.databases.QueryDatabaseRequest;
import notion.api.v1.request.pages.CreatePageRequest;
import notion.api.v1.request.pages.UpdatePageRequest;


/**
 * 
 * En este ejemplo se muestra cómo interactuar con la API de Notion para crear, leer, actualizar y eliminar registros en una base de datos.
 * 
 * Esta clase NO IMPLEMENTA la interfaz IRepository, pero se puede utilizar como base para implementarla.
 * 
 * Además se controlan las excepciones en los métodos de la clase NotionRepository y no se lanzan excepciones (throws) en los métodos.
 * Deberás ingeniartelas para generar las excepciones adecuadas en caso de error.
 * 
 * 
 */
public class NotionRepository implements IRepository{

    private ArrayList<Task> tasks;
    private Task selectedTask;
    private final NotionClient client;
    private final String databaseId;
    private final String titleColumnName = "ID";
    SimpleDateFormat isoFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
    String isoDate = isoFormat.format(new Date());

    public NotionRepository(String apiToken, String databaseId) {
        this.client = new NotionClient(apiToken);
        client.setHttpClient(new OkHttp5Client(60000, 60000, 60000));
        client.setLogger(new Slf4jLogger());
        System.setProperty("notion.api.v1.logging.StdoutLogger", "debug");
    
        this.databaseId = databaseId;
    
        this.tasks = new ArrayList<>();
    }
    

    //Crear un registro en la base de datos (Agregar)
    @Override
    public void agregarTarea(Task t) {
        System.out.println("\u001b[32mCreando una nueva página...\u001b[0m");

        //Convertir la fecha de la tarea a formato ISO 8601
        String isoDate = isoFormat.format(t.getFecha()); //Usa t.getFecha() directamente, que es un Date

        Map<String, PageProperty> properties = Map.of(
                "ID", createTitleProperty(t.getId()),
                "Título", createRichTextProperty(t.getTitulo()),
                "Fecha", createDateProperty(isoDate),  //Usar la fecha en formato ISO 8601
                "Contenido", createRichTextProperty(t.getContenido()),
                "Prioridad", createNumberProperty(t.getPrioridad()),
                "Duración", createNumberProperty(t.getDuracionEstimada()),
                "Completada", createCheckboxProperty(t.isCompletada())
        );

        PageParent parent = PageParent.database(databaseId);

        CreatePageRequest request = new CreatePageRequest(parent, properties);

        Page response = client.createPage(request);

        System.out.println("\u001b[32mPágina creada con ID (interno Notion)\u001b[0m" + response.getId());
    }


    //Obtener todas las tareas
    @Override
    public ArrayList<Task> getTodasTareas() {
        ArrayList<Task> tareas = new ArrayList<>();
        try {
            QueryDatabaseRequest queryRequest = new QueryDatabaseRequest(databaseId);

            QueryResults queryResults = client.queryDatabase(queryRequest);

            for (Page page : queryResults.getResults()) {
                Map<String, PageProperty> properties = page.getProperties();
                Task tar = mapPageToPersona(page.getId(), properties);
                if (tar != null) {
                    tareas.add(tar);
                }
            }

            Collections.sort(tareas, new Comparator<Task>() {
                
                @Override
                public int compare(Task t1, Task t2){
                    return Integer.compare(t2.getPrioridad(), t1.getPrioridad());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
        return tareas;
    }

    //Actualizar un registro por Identifier (Modificar)
    public void modificarTarea(Task t) {
        try {
            String id = Esdia.readString("Introduce el ID de la tarea a modificar: ");
            
            String pageId = findPageIdByIdentifier(id, titleColumnName);
            if (pageId == null) {
                System.out.println("\u001b[31mNo se encontró un registro con el Identifier: \u001b[0m" + id);
                return;
            }
    
            String isoDate = isoFormat.format(t.getFecha());
            
            Map<String, PageProperty> updatedProperties = Map.of(
                "Título", createRichTextProperty(t.getTitulo()),
                "Fecha", createDateProperty(isoDate),
                "Contenido", createRichTextProperty(t.getContenido()),
                "Prioridad", createNumberProperty(t.getPrioridad()),
                "Duración", createNumberProperty(t.getDuracionEstimada()),
                "Completada", createCheckboxProperty(t.isCompletada())
            );
    
            UpdatePageRequest updateRequest = new UpdatePageRequest(pageId, updatedProperties);
            client.updatePage(updateRequest);
    
            System.out.println("\u001b[32mPágina actualizada con ID (interno Notion): \u001b[0m" + pageId);
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Eliminar (archivar) un registro por Identifier
    @Override
    public void eliminarTarea() {
        try {
            String id = Esdia.readString("Introduce el ID de la tarea a eliminar: ");

            String pageId = findPageIdByIdentifier(id, titleColumnName);
            if (pageId == null) {
                System.out.println("\u001b[31mNo se encontró un registro con el Identifier: \u001b[0m" + id);
                return;
            }

            UpdatePageRequest updateRequest = new UpdatePageRequest(pageId, Collections.emptyMap(), true);
            client.updatePage(updateRequest);
            System.out.println("\u001b[32mPágina archivada con ID (interno Notion): \u001b[0m" + pageId);

            tasks.remove(selectedTask);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Metodo para marcar como completada/pendiente una tarea
    @Override
    public void marcarTarea() {
        try {
            String id = Esdia.readString("Introduce el ID de la tarea a modificar: ");
            boolean completada = Esdia.yesOrNo("¿La tarea ha sido completada? ");
            
            String pageId = findPageIdByIdentifier(id, titleColumnName);
            if (pageId == null) {
                System.out.println("\u001b[31mNo se encontró un registro con el Identifier: \u001b[0m" + id);
                return;
            }
            
            Map<String, PageProperty> updatedProperties = Map.of(
                "Completada", createCheckboxProperty(completada)
            );
    
            UpdatePageRequest updateRequest = new UpdatePageRequest(pageId, updatedProperties);
            client.updatePage(updateRequest);
    
            System.out.println("\u001b[32mPágina actualizada con ID (interno Notion): \u001b[0m" + pageId);
    
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //Buscar el ID (interno de Notion) de una página por Identifier (atributo Title de la Database de Notion)
    private String findPageIdByIdentifier(String identifier, String titleColumnName) {
        try {
            QueryDatabaseRequest queryRequest = new QueryDatabaseRequest(databaseId);
            QueryResults queryResults = client.queryDatabase(queryRequest);

            for (Page page : queryResults.getResults()) {
                Map<String, PageProperty> properties = page.getProperties();
                if (properties.containsKey(titleColumnName) &&
                        properties.get(titleColumnName).getTitle().get(0).getText().getContent().equals(identifier)) {
                    return page.getId();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Métodos auxiliares para crear propiedades de página
    private PageProperty createTitleProperty(String title) {
        RichText idText = new RichText();
        idText.setText(new Text(title));
        PageProperty idProperty = new PageProperty();
        idProperty.setTitle(Collections.singletonList(idText));
        return idProperty;
    }

    //Metodos auxiliares para crear propiedades de página
    private PageProperty createRichTextProperty(String text) {
        RichText richText = new RichText();
        richText.setText(new Text(text));
        PageProperty property = new PageProperty();
        property.setRichText(Collections.singletonList(richText));
        return property;
    }

    private PageProperty createNumberProperty(Integer number) {
        PageProperty property = new PageProperty();
        property.setNumber(number);
        return property;
    }

    private PageProperty createDateProperty(String date) {
        PageProperty property = new PageProperty();
        PageProperty.Date dateProperty = new PageProperty.Date();
        dateProperty.setStart(date);
        property.setDate(dateProperty);
        return property;
    }

    private PageProperty createCheckboxProperty(boolean checked) {
        PageProperty property = new PageProperty();
        property.setCheckbox(checked);
        return property;
    }

    //Mapeo de propiedades de Notion a un objeto Tareas
    private Task mapPageToPersona(String pageId, Map<String, PageProperty> properties) {
        try {
            Task t = new Task();
            t.setId(properties.get("ID").getTitle().get(0).getText().getContent());
            t.setTitulo(properties.get("Título").getRichText().get(0).getText().getContent());
            
            String fechaString = properties.get("Fecha").getDate().getStart();
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
            Date fecha = formatter.parse(fechaString);
            t.setFecha(fecha);

            t.setContenido(properties.get("Contenido").getRichText().get(0).getText().getContent());
            t.setPrioridad(properties.get("Prioridad").getNumber().intValue());
            t.setDuracionEstimada(properties.get("Duración").getNumber().intValue());
            t.setCompletada(properties.get("Completada").getCheckbox());
            return t;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
