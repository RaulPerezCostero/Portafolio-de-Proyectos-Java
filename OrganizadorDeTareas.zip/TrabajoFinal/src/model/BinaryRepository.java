package model;

import java.util.ArrayList;

import com.coti.tools.Esdia;

public class BinaryRepository implements IRepository{
    
    //Atributos
    private ArrayList<Task> tareas = new ArrayList<>();

    //Metodos CRUD
    @Override
    public void agregarTarea(Task t) {
        if(tareas.contains(t)){
            System.err.println("\u001b[31mNo se ha podido agregar la tarea porque ya esta en lista de tareas.\u001b[0m");
        }else{
            tareas.add(t);
            System.out.println("\u001b[32mTarea añadida correctamente.\u001b[0m");
        }
    }

    @Override
    public void modificarTarea(Task t) {
        if(tareas.isEmpty()){
            System.err.println("\u001b[31mAun no hay tareas que se puedan modificar.\u001b[0m");
        }else{
            Task modificado = null;
            String id = Esdia.readString("Introduce la ID de la tarea a modificar: ");
            for (Task task : tareas) {
                if(task.getId().equals(id)){
                    modificado = task;
                    break;
                }
            }
            if(modificado != null){
                modificado.setTitulo(t.getTitulo());
                modificado.setFecha(t.getFecha());
                modificado.setContenido(t.getContenido());
                modificado.setPrioridad(t.getPrioridad());
                modificado.setDuracionEstimada(t.getDuracionEstimada());
                modificado.setCompletada(t.isCompletada());
                System.out.println("\u001b[32mTarea modificada correctamente.\u001b[0m");
            }else{
                System.err.println("\u001b[31mNo se encontró una tarea con ese ID\u001b[0m");
            }
        }
        
    }

    @Override
    public void eliminarTarea() {
        if(tareas.isEmpty()){
            System.err.println("\u001b[31mAun no hay tareas que se puedan eliminar.\u001b[0m");
        
        }else{
            String id = Esdia.readString("Introduce la ID de la tarea a eliminar: ");
            Task eliminar =  null;

            for (Task task : tareas) {
                if(task.getId().equals(id)){
                    eliminar = task;
                    break;
                }
            }
            if(eliminar != null){
                tareas.remove(eliminar);
                System.out.println("\u001b[32mTarea con ID " + id + " eliminada correctamente.\u001b[0m");
            }else{
                System.err.println("\u001b[31mNo se encontró ninguna tarea con el ID especificado. Inténtalo de nuevo.\u001b[0m");
            }
            
        }
    }

    public void marcarTarea(){
        if(tareas.isEmpty()){
            System.err.println("\u001b[31mAun no hay tareas que se puedan marcar como completadas.\u001b[0m");
        }else{
            String id = Esdia.readString("Introduce la ID de la tarea a marcar como completada/pendiente: ");
            Task modificar =  null;
            for (Task task : tareas) {

                if(task.getId().equals(id)){
                    modificar = task;
                    break;
                }
            }
            if(modificar != null){
                boolean nuevoCompletada = Esdia.yesOrNo("¿La tarea ya ha sido completada? ");
                modificar.setCompletada(nuevoCompletada);
                System.out.println("\u001b[32mTarea con ID " + id + " modificada correctamente.\u001b[0m");
            }else{
                System.err.println("\u001b[31mNo se encontró ninguna tarea con el ID especificado. Inténtalo de nuevo.\u001b[0m");
            }
            
        }
    }

    @Override
    public ArrayList<Task> getTodasTareas() {
        return new ArrayList<>(tareas);
    }

}
