package model;

public class RepositoryException extends Exception {

    //Constructores de la clase con distintos argumentos
    public RepositoryException(){

    }

    public RepositoryException(Throwable cause){
        super(cause);
    }

    public RepositoryException(String message){
        super(message);
    }

    public RepositoryException(String message, Throwable cause){
        super(message, cause);
    }
}
