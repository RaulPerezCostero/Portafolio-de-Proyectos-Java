package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;

import com.coti.tools.Rutas;

public class Model {
    
    //Atributos
    IRepository repositorio;
    IExporter exportador;
    ArrayList<Task> tareas = new ArrayList<>();
    private Set<String> idsDesdeBinario = new HashSet<>();
    Path rutaBIN = Rutas.pathToFileOnDesktop("tareas.bin");

    //Constructor
    public Model(IRepository repositorio){
        this.repositorio = repositorio;
    }

    //Metodo que establece un exportador
    public void setExportador(IExporter exportador){
        this.exportador = exportador;
        if (exportador instanceof CSVExporter) {
            ((CSVExporter) exportador).setIdsDesdeBinario(this.idsDesdeBinario);
        }
    }

    //Metodo que carga los datos de un archivo al repositorio
    public void cargarDatos(){
        if(exportador == null)
            throw new IllegalThreadStateException("\u001b[31mNo se ha configurado el exportador.\u001b[0m");

        tareas = exportador.importarTareas();
        for (Task task : tareas) {
            repositorio.agregarTarea(task);
        }
        
    }

    //Metodo que guarda los datos  del repositorio en un archivo
    public void guardarDatos() throws RepositoryException{
        if(exportador == null)
            throw new RepositoryException("\u001b[31mNo se ha configurado el exportador.\u001b[0m");
        
        tareas = repositorio.getTodasTareas();
        exportador.exportarTareas(tareas);
    }

    //Metodos CRUD (Llamada a BinaryRepository)
    public void agregarTarea(Task t){
        repositorio.agregarTarea(t);
    }

    public void modificarTarea(Task t){
        repositorio.modificarTarea(t);
    }

    public void eliminarTarea(){
        repositorio.eliminarTarea();
    }

    public void marcarTarea(){
        repositorio.marcarTarea();
    }

    //Metodos Exportar/Importar
    public void exportar(ArrayList<Task> tareas){
        exportador.exportarTareas(tareas);
    }

    public void importar(){
        exportador.importarTareas();
    }

    //Metodos de listar
    public ArrayList<Task> listarTareas(){
        return repositorio.getTodasTareas();
    }

    public ArrayList<Task> listarTareasOrdenadas(){
            ArrayList<Task> tareas = listarTareas();

            tareas.removeIf(task -> task.isCompletada()); //Condicion especificada con una expresion lambda (A cada elemento de la lista se le asigna el nombre "task" y para cada uno "->" ve si se ha comppletado o no "task.isCompletada()")

            Collections.sort(tareas, new Comparator<Task>() {
                
                @Override
                public int compare(Task t1, Task t2){
                    return Integer.compare(t2.getPrioridad(), t1.getPrioridad());
                }
            });

            return tareas;
    }

    //Metodo de Deserializacion
    public boolean deserializar() {
        File f = rutaBIN.toFile();
    
        if (f.exists() && f.isFile() && f.length() > 0) {
            try (FileInputStream fileInputStream = new FileInputStream(f);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream)) {
    
                @SuppressWarnings("unchecked")
                ArrayList<Task> listaObjeto = (ArrayList<Task>) objectInputStream.readObject();
                
                this.tareas = listaObjeto;
                
                for (Task task : tareas) {
                    if (task.getId() != null) {
                        idsDesdeBinario.add(task.getId());
                        repositorio.agregarTarea(task);
                    }
                }
    
                objectInputStream.close();
                return true;
    
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Error al deserializar: " + e.getMessage());
                e.printStackTrace();
                return false;
            }
        } else {
            System.err.println("\u001b[31mEl archivo no existe, no es válido o está vacío.\u001b[0m");
        }

        return false;
    }
    

    //Metodo de Seriaizacion
    public boolean serializar() {
        File f = rutaBIN.toFile();
    
        try (FileOutputStream fileOutputStream = new FileOutputStream(f);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream)) {
    
            objectOutputStream.writeObject(tareas);
            objectOutputStream.close();

            return true;
        } catch (IOException e) {
            System.err.println("\u001b[31mError al serializar: \u001b[0m" + e.getMessage());
            e.printStackTrace();
        }
    
        return false;
    }


    //Metodo para centrar texto
    public void centrarTexto(String texto) {
        int terminalWidth = 160;

        String[] lines = texto.split("\n");

        for (String line : lines) {
            int padding = (terminalWidth - line.length()) / 2;

            StringBuilder spaces = new StringBuilder();
            for (int i = 0; i < padding; i++) {
                spaces.append(" ");
            }

            System.out.println(spaces.toString() + line);
        }
    }


}
