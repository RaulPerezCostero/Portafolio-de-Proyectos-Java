package model;

public class ExporterFactory {

    //Como no depende de ningun atributo pondremos "static" para mayor sencillez al usar el metodo.
    //Usaremos ".toLowerCase" para convertir "tipo" en minusculas para facilitar la entrada. Aunque se podria omitir esta transformacion.
    
    public static IExporter getExporter(String tipo){
        switch (tipo.toLowerCase()) {
            case "csv":
                return new CSVExporter();

            case "json":
                return new JSONExporter();

            default:
                throw new IllegalArgumentException("\u001b[31mTipo de exportador no soportado: \u001b[0m" + tipo);
                
        }
    }
}
