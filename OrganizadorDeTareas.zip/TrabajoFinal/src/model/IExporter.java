package model;

import java.util.ArrayList;

public interface IExporter {

    public void exportarTareas(ArrayList<Task> tareas);

    public ArrayList<Task> importarTareas();

}