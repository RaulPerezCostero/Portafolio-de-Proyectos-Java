package controller;

import java.util.ArrayList;

import model.ExporterFactory;
import model.Model;
import model.RepositoryException;
import model.Task;
import view.BaseView;

public class Controller {

    //Atributos
    BaseView view;
    Model model;

    //Constructor
    public Controller(BaseView view, Model model){
        this.view = view;
        this.model = model;
        this.view.setController(this);
    }

    //Metodo de inicializacion (Llamada al modelo)
    public void initProgram(){

        //Inicio del programa
        if(model.deserializar()){
            view.showMessage("\u001b[32mSe ha cargado la informacion del binario.\u001b[0m");
        }else{
            view.showMessage("\u001b[31mHa habido un error al cargar el binario.\u001b[0m");
        }
    
        //Mostrar menu
        view.showMenu();

        //Fin del programa
        if(model.serializar()){
            view.showMessage("\u001b[32mSe ha guardado la informacion en el binario.\u001b[0m");
        }else{
            view.showMessage("\u001b[31mHa habido un error al guardar los datos en el binario.\u001b[0m");
        }
    }

    //Menu Notion
    public void initView(){
        view.showMenu();
    }

    //Metodos CRUD (Llamada al modelo)
    public void agregarTarea(Task t){
        model.agregarTarea(t);
    }

    public void marcarTarea(){
        model.marcarTarea();
    }

    public void modificarTarea(Task t){
        model.modificarTarea(t);
    }

    public void eliminarTarea(){
        model.eliminarTarea();
    }

    //Metodos Importar/Exportar (Llamada al modelo)
    public void importar(String formato) {
        model.setExportador(ExporterFactory.getExporter(formato));
        model.cargarDatos();
    }

    public void exportar(String formato) {
            model.setExportador(ExporterFactory.getExporter(formato));
            try {
                model.guardarDatos();
            } catch (RepositoryException e) {
                System.err.println("\u001b[31mError al exportar los datos.\u001b[0m");
                e.printStackTrace();
            }

    }

    //Metodos Listar (Llamada al modelo)
    public ArrayList<Task> listarTareasOrdenadas(){
        return model.listarTareasOrdenadas();
    }

    public void listarTareas(){
        ArrayList<Task> tareas = model.listarTareas();
        if (tareas.isEmpty()) {
            view.showMessage("\u001b[31m                 | No hay tareas para mostrar.                                                                                                       |\u001b[0m");
        } else {
            for (Task t : tareas) {
                view.showMessage(t.toString());
            }
        }
    }

    //Metodo para centrar (Llamada al modelo)
    public void centrarTexto(String texto){
        model.centrarTexto(texto);
    }


}
