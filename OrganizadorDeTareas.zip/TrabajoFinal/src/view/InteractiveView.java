package view;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import com.coti.tools.Esdia;

import controller.Controller;
import model.Task;

public class InteractiveView extends BaseView {

    //Atributos
    UUID id;
    Controller controller;
    int terminalWidth = 170;

    //Metodos de la clase abstracta BaseView
    @Override
    public void init() {
        
    }

    @Override
    public void showMessage(String msg) {
        System.out.println(msg);
    }

    @Override
    public void showErrorMessage(String msg) {
        System.out.println(msg);
    }

    @Override
    public void end(String msgDespedida) {
        System.out.println(msgDespedida);
    }

    @Override
    public void showMenu() {
        int option;
        boolean atras = false;

        do {

            String menuPrincipal = "|----------------------------------------------|\n"
                + "|                 Menu Principal               |\n"
                + "|----------------------------------------------|\n"
                + "| 1- Gestion de tareas.                        |\n"
                + "| 2- Importar/Exportar tareas.                 |\n"
                + "| 3- Listado de tareas.                        |\n"
                + "| 0- Salir.                                    |\n"
                + "|----------------------------------------------|";
            controller.centrarTexto(menuPrincipal);

            option = Esdia.readInt("Elige una opcion entre 1-3: " );

            for (int i = 0; i < 50; i++) {
                System.out.println();
            }

            switch (option) {
                case 1:
                    subMenuCRUD();
                    break;

                case 2:
                    subMenuImportarExportar();
                    break;
                case 3:
                    subMenuListado();
                    break;
                case 0:
                    atras = true;
                    System.out.println("\u001b[33mSaliendo...\u001b[0m");
                    break;

                default:
                    System.out.println("\u001b[31mOpcion invalida.\u001b[0m");
                    break;

            }

        } while (!atras);
    }

    //Metodos SubMenus
    private void subMenuCRUD(){
        int option;
        boolean atras = false;

        do {

            String menuGestionTareas = "|----------------------------------------------|\n"
                + "|              Gestion de Tareas               |\n"
                + "|----------------------------------------------|\n"
                + "| 1- Agregar una tarea.                        |\n"
                + "| 2- Marcar como completa/incompleta.          |\n"
                + "| 3- Modificar una tarea.                      |\n"
                + "| 4- Eliminar tarea.                           |\n"
                + "| 0- Volver al menu principal.                 |\n"
                + "|----------------------------------------------|";
        
            controller.centrarTexto(menuGestionTareas);
            option = Esdia.readInt("Elige una opcion entre 1-4: ");

            for (int i = 0; i < 50; i++) {
                System.out.println();
            }

            switch (option) {
                case 1:
                    agregarTarea();
                    break;

                case 2:
                    marcarTarea();
                    break;

                case 3:
                    modificarTarea();
                    break;

                case 4:
                    eliminarTarea();
                    break;

                case 0:
                atras = true;
                    System.out.println("\u001b[33mVolviendo al menu principal...\u001b[0m");
                    break;

                default:
                    System.out.println("\u001b[31mOpcion invalida\u001b[0m");
                    break;

            }

        } while (!atras);
    }

    private void subMenuImportarExportar(){
        int option;
        boolean atras = false;

        do {

            String menuImportarExportar = "|----------------------------------------------|\n"
                + "|                Importar/Exportar             |\n"
                + "|----------------------------------------------|\n"
                + "| 1- Importar desde CSV.                       |\n"
                + "| 2- Importar desde JSON.                      |\n"
                + "| 3- Exportar a CSV.                           |\n"
                + "| 4- Exportar a JSON.                          |\n"
                + "| 0- Volver al menu principal.                 |\n"
                + "|----------------------------------------------|";
        
            
            controller.centrarTexto(menuImportarExportar);

            option = Esdia.readInt("Elige una opcion entre 1-4: ");

            for (int i = 0; i < 50; i++) {
                System.out.println();
            }

            switch (option) {
                case 1:
                    importarCSV();
                    break;

                case 2:
                    importarJSON();
                    break;

                case 3:
                    exportarCSV();
                    break;

                case 4:
                    exportarJSON();
                    break;

                case 0:
                    atras = true;
                    System.out.println("\u001b[33mVolviendo al menu principal...\u001b[0m");
                    break;

                default:
                    System.out.println("\u001b[31mOpcion invalida\u001b[0m");
                    break;

            }

        } while (!atras);
    }


    private void subMenuListado(){
        int option;
        boolean atras = false;

        do {

            String menuListadoTareas = "|----------------------------------------------|\n"
                + "|               Listado de Tareas              |\n"
                + "|----------------------------------------------|\n"
                + "| 1- Listado de tareas ordenado por prioridad. |\n"
                + "| 2- Listado completo de tareas.               |\n"
                + "| 0- Volver al menu principal.                 |\n"
                + "|----------------------------------------------|";

            controller.centrarTexto(menuListadoTareas);
            option = Esdia.readInt("Elige una opcion entre 1-2: ");

            for (int i = 0; i < 50; i++) {
                System.out.println();
            }

            switch (option) {
                case 1:
                    listarTareasOrdenadas();
                    break;

                case 2:
                    listarTareas();
                    break;

                case 0:
                    atras = true;
                    System.out.println("\u001b[33mVolviendo al menu principal...\u001b[0m");
                    break;

                default:
                    System.out.println("\u001b[31mOpcion invalida\u001b[0m");
                    break;

            }

        } while (!atras);
    }

    //Metodos CRUD (Llamada al controlador)
    public void agregarTarea(){
        String titulo = Esdia.readString("Introduce el titulo de la tarea: ");

        Date fecha = null;
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        dateFormat.setLenient(false);
        boolean fechaValida = false;
        
        while (!fechaValida) {
            String fechaStr = Esdia.readString("Introduce la fecha de la tarea (formato: dd/MM/yyyy): ");
            try {
                fecha = dateFormat.parse(fechaStr);
                fechaValida = true;
            } catch (ParseException e) {
                System.out.println("\u001b[31mFormato de fecha inválido. Intenta nuevamente.\u001b[0m");
            }
        }
        
        String contenido = Esdia.readString("Introduce el contenido de la tarea: ");
        int prioridad = Esdia.readInt("Introduce la prioridad de esta tarea del 1-5 siendo 1 poca prioridad y 5 mucha: ",1,5);
        int duracionEstimada = Esdia.readInt("Introduce la duracion aproximada de la tarea en minutos: ");
        boolean completada = Esdia.yesOrNo("¿La tarea ya ha sido completada? ");

        Task tarea = new Task(titulo, fecha, contenido, prioridad, duracionEstimada, completada);

        controller.agregarTarea(tarea);
    }

    public void marcarTarea(){
        controller.marcarTarea();
    }

    public void modificarTarea(){
            String nuevoTitulo = Esdia.readString("Introduce el nuevo titulo de la tarea: ");
            
            Date nuevaFecha = null;
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            dateFormat.setLenient(false);
            boolean fechaValida = false;
            
            while (!fechaValida) {
                String fechaStr = Esdia.readString("Introduce la fecha de la tarea (formato: dd/MM/yyyy): ");
                try {
                    nuevaFecha = dateFormat.parse(fechaStr);
                    fechaValida = true;
                } catch (ParseException e) {
                    System.out.println("\u001b[31mFormato de fecha inválido. Vuelve a intentarlo.\u001b[31m");
                }
            }

            String nuevoContenido = Esdia.readString("Introduce el nuevo contenido de la tarea: ");
            int nuevaPrioridad = Esdia.readInt("Introduce la prioridad de esta tarea del 1-5 siendo 1 poca prioridad y 5 mucha: ",1,5);
            int nuevaDuracionEstimada = Esdia.readInt("Introduce la duracion aproximada de la tarea en minutos: ");
            boolean nuevoCompletada = Esdia.yesOrNo("¿La tarea ya ha sido completada? ");

            Task modificar = new Task(nuevoTitulo, nuevaFecha, nuevoContenido, nuevaPrioridad, nuevaDuracionEstimada, nuevoCompletada);

            controller.modificarTarea(modificar);
    }

    public void eliminarTarea(){
        controller.eliminarTarea();
    }

    //Metodos Importar/Exportar (Llamada al controlador)
    public void importarCSV(){
        controller.importar("csv");
    }

    public void importarJSON(){
        controller.importar("json");
    }

    public void exportarCSV(){
        controller.exportar("csv");
    }

    public void exportarJSON(){
        controller.exportar("json");
    }

    //Metodos Listar (Llamada al controlador)
    public void listarTareasOrdenadas(){
        ArrayList<Task> tareas = controller.listarTareasOrdenadas();
        System.out.println();
        System.out.println("\u001b[32m                 |" + "-".repeat(131) + "|");
        System.out.printf("                 | %-36s | %-25s | %-20s | %-11s | %-11s | %-11s | \n", "ID", "Título", "Fecha de vencimiento", "Prioridad", "Duración", "Completada" );
        System.out.println("                 |" + "-".repeat(131) + "|\u001b[0m");
        for (Task t : tareas) {
            showMessage(t.toString());
        }

        if (tareas.isEmpty()){
            System.out.println("\u001b[31m                 | No hay tareas sin completar para mostrar.                                                                                         |\u001b[0m");
        }

        System.out.println("\u001b[32m                 |" + "-".repeat(131) + "|\u001b[0m");
        System.out.println();
        System.out.println();
        System.out.println();
    }

    public void listarTareas(){
        System.out.println();
        System.out.println("\u001b[32m                 |" + "-".repeat(131) + "|");
        System.out.printf("                 | %-36s | %-25s | %-20s | %-11s | %-11s | %-11s | \n", "ID", "Título", "Fecha de vencimiento", "Prioridad", "Duración", "Completada" );
        System.out.println("                 |" + "-".repeat(131) + "|\u001b[0m");
        controller.listarTareas();
        System.out.println("\u001b[32m                 |" + "-".repeat(131) + "|\u001b[0m");
        
        System.out.println();
        System.out.println();
        System.out.println();
    }


    //Metodo setter para establecer el valor del atributo
    public void setController(Controller controller){
        this.controller = controller;
    }

    
}
