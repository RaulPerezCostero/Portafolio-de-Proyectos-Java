package view;

public class CLIView extends BaseView{ //Implementar en un futuro
    
    //Constructor vacio
    public CLIView(){

    }

    //Metodos de la interfaz
    @Override
    public void init() {
        System.out.println("\u001b[33mVista en preparacion. Implementación futura.\u001b[0m");
    }

        @Override
    public void showMessage(String msg) {
        System.out.println("[CLIView] " + msg);
    }
    
    @Override
    public void showErrorMessage(String msg) {
        System.err.println("[CLIView - ERROR] " + msg);
    }
    
    @Override
    public void showMenu() {
        System.out.println("[CLIView] \u001b[33mVista en preparacion. Implementación futura.\u001b[0m");
    }
    
    @Override
    public void end(String msgDespedida) {
        System.out.println("[CLIView] " + msgDespedida);
    }
}
