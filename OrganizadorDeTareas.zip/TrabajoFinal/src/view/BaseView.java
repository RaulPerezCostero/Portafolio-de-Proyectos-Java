package view;

import controller.Controller;

public abstract class BaseView {

    //Atributos
    protected Controller c;

    //Metodos concretos
    public void setController(Controller c){
        this.c = c;
    }

    //Metodos abstractos
    public abstract void init();

    public abstract void showMenu();

    public abstract void showMessage(String msg);

    public abstract void showErrorMessage(String msg);

    public abstract void end(String msgDespedida);

}
