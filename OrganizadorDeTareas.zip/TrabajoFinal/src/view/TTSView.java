package view;

public class TTSView extends BaseView{ //Implementar en un futuro

    //Constructor vacio
    public TTSView(){

    }

    //Metodos de la interfaz
    @Override
    public void init() {
        System.out.println("\u001b[33mVista en preparacion. Implementación futura.\u001b[0m");
    }

        @Override
    public void showMessage(String msg) {
        System.out.println("[TTSView] " + msg);
    }
    
    @Override
    public void showErrorMessage(String msg) {
        System.err.println("[TTSView - ERROR] " + msg);
    }
    
    @Override
    public void showMenu() {
        System.out.println("[TTSView] \u001b[33mVista en preparacion. Implementación futura.\u001b[0m");
    }
    
    @Override
    public void end(String msgDespedida) {
        System.out.println("[TTSView] " + msgDespedida);
    }
    
}
