import controller.Controller;
import model.BinaryRepository;
import model.IRepository;
import model.Model;
import model.NotionRepository;
import view.BaseView;
import view.CLIView;
import view.InteractiveView;
import view.TTSView;

public class App {
    public static void main(String[] args) throws Exception {

        IRepository repository; //java --enable-preview -jar TrabajoFinal.jar --repository view bin
        BaseView view;          //java --enable-preview -jar app.jar --repository view notion API-KEY dataBase_ID

        //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 (API-KEY)
        //156bd567e563805a9b41d4a6944d6b44 (dataBase_ID)

        if (args[2].equals("bin")) {

            view = getViewForoption(args[1]);
            repository = new BinaryRepository();

        } else if (args[2].equals("notion")) {

            view = getViewForoption(args[1]);
            repository = new NotionRepository(args[3], args[4]);

        } else {

            view = new InteractiveView();
            repository = new BinaryRepository();
        }

        Model model = new Model(repository);
        Controller controller = new Controller(view, model);

        if (args[2].equals("notion")){
            controller.initView();

        } else if(args[1].equals("tts") || args[1].equals("cli")){
            controller.initView();

        } else{
            controller.initProgram();
        }
        
    }

    //Organizador de vistas
    private static BaseView getViewForoption(String key) {
        switch (key) {
            case "view":
                return new InteractiveView();
            case "cli":
                return new CLIView(); //Implementación futura (Reparación)
            case "tts":
                return new TTSView(); //Implementación futura (Reparación)
            default:
                return new InteractiveView();
        }
    }
}
