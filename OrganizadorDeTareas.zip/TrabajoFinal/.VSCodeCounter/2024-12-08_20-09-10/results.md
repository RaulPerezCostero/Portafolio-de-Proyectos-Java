# Summary

Date : 2024-12-08 20:09:10

Directory c:\\Users\\Raúl\\OneDrive\\Escritorio\\Universidad\\Estadística\\3º Estadística\\1º Cuatrimestre\\Programación lll\\RepositorioGitHub\\proglll-2425-PA4\\Trabajo Final\\TrabajoFinal

Total : 37 files,  1988 codes, 62 comments, 367 blanks, all 2417 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Java | 36 | 1,978 | 62 | 358 | 2,398 |
| Markdown | 1 | 10 | 0 | 9 | 19 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 37 | 1,988 | 62 | 367 | 2,417 |
| . (Files) | 1 | 10 | 0 | 9 | 19 |
| bin | 20 | 814 | 0 | 2 | 816 |
| bin (Files) | 1 | 26 | 0 | 0 | 26 |
| bin\\controller | 1 | 42 | 0 | 0 | 42 |
| bin\\model | 14 | 510 | 0 | 2 | 512 |
| bin\\view | 4 | 236 | 0 | 0 | 236 |
| src | 16 | 1,164 | 62 | 356 | 1,582 |
| src (Files) | 1 | 44 | 2 | 13 | 59 |
| src\\controller | 1 | 73 | 11 | 23 | 107 |
| src\\model | 10 | 712 | 40 | 203 | 955 |
| src\\view | 4 | 335 | 9 | 117 | 461 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)