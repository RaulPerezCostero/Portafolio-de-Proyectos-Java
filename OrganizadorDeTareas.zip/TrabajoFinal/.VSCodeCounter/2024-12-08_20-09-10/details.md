# Details

Date : 2024-12-08 20:09:10

Directory c:\\Users\\Raúl\\OneDrive\\Escritorio\\Universidad\\Estadística\\3º Estadística\\1º Cuatrimestre\\Programación lll\\RepositorioGitHub\\proglll-2425-PA4\\Trabajo Final\\TrabajoFinal

Total : 37 files,  1988 codes, 62 comments, 367 blanks, all 2417 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.md](/README.md) | Markdown | 10 | 0 | 9 | 19 |
| [bin/App.class](/bin/App.class) | Java | 26 | 0 | 0 | 26 |
| [bin/controller/Controller.class](/bin/controller/Controller.class) | Java | 42 | 0 | 0 | 42 |
| [bin/model/BinaryRepository.class](/bin/model/BinaryRepository.class) | Java | 51 | 0 | 0 | 51 |
| [bin/model/CSVExporter$1.class](/bin/model/CSVExporter$1.class) | Java | 13 | 0 | 0 | 13 |
| [bin/model/CSVExporter.class](/bin/model/CSVExporter.class) | Java | 47 | 0 | 0 | 47 |
| [bin/model/ExporterFactory.class](/bin/model/ExporterFactory.class) | Java | 15 | 0 | 0 | 15 |
| [bin/model/IExporter.class](/bin/model/IExporter.class) | Java | 3 | 0 | 1 | 4 |
| [bin/model/IRepository.class](/bin/model/IRepository.class) | Java | 5 | 0 | 0 | 5 |
| [bin/model/JSONExporter$1.class](/bin/model/JSONExporter$1.class) | Java | 8 | 0 | 0 | 8 |
| [bin/model/JSONExporter$2.class](/bin/model/JSONExporter$2.class) | Java | 13 | 0 | 0 | 13 |
| [bin/model/JSONExporter.class](/bin/model/JSONExporter.class) | Java | 48 | 0 | 0 | 48 |
| [bin/model/Model$1.class](/bin/model/Model$1.class) | Java | 16 | 0 | 0 | 16 |
| [bin/model/Model.class](/bin/model/Model.class) | Java | 101 | 0 | 1 | 102 |
| [bin/model/NotionRepository.class](/bin/model/NotionRepository.class) | Java | 123 | 0 | 0 | 123 |
| [bin/model/RepositoryException.class](/bin/model/RepositoryException.class) | Java | 19 | 0 | 0 | 19 |
| [bin/model/Task.class](/bin/model/Task.class) | Java | 48 | 0 | 0 | 48 |
| [bin/view/BaseView.class](/bin/view/BaseView.class) | Java | 11 | 0 | 0 | 11 |
| [bin/view/CLIView.class](/bin/view/CLIView.class) | Java | 35 | 0 | 0 | 35 |
| [bin/view/InteractiveView.class](/bin/view/InteractiveView.class) | Java | 156 | 0 | 0 | 156 |
| [bin/view/TTSView.class](/bin/view/TTSView.class) | Java | 34 | 0 | 0 | 34 |
| [src/App.java](/src/App.java) | Java | 44 | 2 | 13 | 59 |
| [src/controller/Controller.java](/src/controller/Controller.java) | Java | 73 | 11 | 23 | 107 |
| [src/model/BinaryRepository.java](/src/model/BinaryRepository.java) | Java | 78 | 0 | 12 | 90 |
| [src/model/CSVExporter.java](/src/model/CSVExporter.java) | Java | 87 | 0 | 19 | 106 |
| [src/model/ExporterFactory.java](/src/model/ExporterFactory.java) | Java | 13 | 2 | 7 | 22 |
| [src/model/IExporter.java](/src/model/IExporter.java) | Java | 6 | 0 | 5 | 11 |
| [src/model/IRepository.java](/src/model/IRepository.java) | Java | 9 | 0 | 10 | 19 |
| [src/model/JSONExporter.java](/src/model/JSONExporter.java) | Java | 78 | 0 | 15 | 93 |
| [src/model/Model.java](/src/model/Model.java) | Java | 118 | 11 | 45 | 174 |
| [src/model/NotionRepository.java](/src/model/NotionRepository.java) | Java | 199 | 21 | 50 | 270 |
| [src/model/RepositoryException.java](/src/model/RepositoryException.java) | Java | 14 | 0 | 7 | 21 |
| [src/model/Task.java](/src/model/Task.java) | Java | 110 | 6 | 33 | 149 |
| [src/view/BaseView.java](/src/view/BaseView.java) | Java | 13 | 3 | 11 | 27 |
| [src/view/CLIView.java](/src/view/CLIView.java) | Java | 25 | 0 | 10 | 35 |
| [src/view/InteractiveView.java](/src/view/InteractiveView.java) | Java | 272 | 6 | 86 | 364 |
| [src/view/TTSView.java](/src/view/TTSView.java) | Java | 25 | 0 | 10 | 35 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)